package CommonUtils.string;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
// --- <<IS-END-IMPORTS>> ---

public final class javaUtils

{
	// ---( internal utility methods )---

	final static javaUtils _instance = new javaUtils();

	static javaUtils _newInstance() { return new javaUtils(); }

	static javaUtils _cast(Object o) { return (javaUtils)o; }

	// ---( server methods )---




	public static final void splitStringByChunks (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(splitStringByChunks)>> ---
		// @sigtype java 3.5
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	inString = IDataUtil.getString( pipelineCursor, "inString" );
		Integer chunkLength = Integer.parseInt(IDataUtil.getString( pipelineCursor, "chunkLength" ));
		int size = 0;
							
		byte[] bytes;
		String[] splittedPartString = null;
		
		try {
			bytes = inString.getBytes("utf-8");
			System.out.println("bytes = "+Arrays.toString(bytes));
			System.out.println("bytes.length = "+bytes.length);
			
			size=bytes.length;
			splittedPartString = splitInParts(inString, chunkLength);
			
			//String[] splittedString=inString.
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
		
		IDataUtil.put( pipelineCursor, "size", size );
		String[]	splittedString = splittedPartString;
		//splittedString[0] = "splittedString";
		IDataUtil.put( pipelineCursor, "splittedString", splittedString );
		
		
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	//Splitting String in chunks
		public static String[] splitInParts(String s, int partLength)
		{
		    int len = s.length();
		
		    // Number of parts
		    int nparts = (len + partLength - 1) / partLength;
		    String parts[] = new String[nparts];
		
		    // Break into parts
		    int offset= 0;
		    int i = 0;
		    while (i < nparts)
		    {
		        parts[i] = s.substring(offset, Math.min(offset + partLength, len));
		        offset += partLength;
		        i++;
		    }
		
		    return parts;
		}
	// --- <<IS-END-SHARED>> ---
}

