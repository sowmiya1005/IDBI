package SIDBICrypto.services;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
// --- <<IS-END-IMPORTS>> ---

public final class doubleDecryption

{
	// ---( internal utility methods )---

	final static doubleDecryption _instance = new doubleDecryption();

	static doubleDecryption _newInstance() { return new doubleDecryption(); }

	static doubleDecryption _cast(Object o) { return (doubleDecryption)o; }

	// ---( server methods )---




	public static final void doubleDecrypt (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(doubleDecrypt)>> ---
		// @sigtype java 3.5
		// [i] field:0:required encryptedText
		// [i] field:0:required sidbiPublicKey
		// [i] field:0:required idbiPrivateKey
		// [o] field:0:required plainText
		// [o] field:0:optional errorMsg
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	encryptedText = IDataUtil.getString( pipelineCursor, "encryptedText" );
		String	sidbiPublicKey = IDataUtil.getString( pipelineCursor, "sidbiPublicKey" );
		String	idbiPrivateKey = IDataUtil.getString( pipelineCursor, "idbiPrivateKey" );
		pipelineCursor.destroy();
		
		String decryptedString=null;
		String decryptedStringPK=null;
		String errorMsg=null;
		
		try {
			decryptedStringPK = decryptPK(encryptedText,sidbiPublicKey);
			decryptedString = decrypt(decryptedStringPK,idbiPrivateKey);
			} catch (NoSuchAlgorithmException e) {
			errorMsg=e.getMessage();
			} catch (InvalidKeyException e) {
			errorMsg=e.getMessage();
			} catch (IllegalBlockSizeException e) {
			errorMsg=e.getMessage();
			} catch (BadPaddingException e) {
			errorMsg=e.getMessage();
			} catch (NoSuchPaddingException e) {
			errorMsg=e.getMessage();
			}
		
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "plainText", decryptedString );
		if(errorMsg!=null) IDataUtil.put( pipelineCursor, "errorMsg", errorMsg );
		pipelineCursor_1.destroy();		
			
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	//Extracting Public Key
	public static PublicKey getPublicKey(String base64PublicKey){
	    PublicKey publicKey = null;
	    try{
	        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(base64PublicKey.getBytes()));
	        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
	        publicKey = keyFactory.generatePublic(keySpec);
	        return publicKey;
	    } catch (NoSuchAlgorithmException e) {
	        e.printStackTrace();
	    } catch (InvalidKeySpecException e) {
	        e.printStackTrace();
	    }
	    return publicKey;
	}
	
	//Extracting Private Key
	public static PrivateKey getPrivateKey(String base64PrivateKey){
	    PrivateKey privateKey = null;
	    PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(base64PrivateKey.getBytes()));
	    KeyFactory keyFactory = null;
	    try {
	        keyFactory = KeyFactory.getInstance("RSA");
	    } catch (NoSuchAlgorithmException e) {
	        e.printStackTrace();
	    }
	    try {
	        privateKey = keyFactory.generatePrivate(keySpec);
	    } catch (InvalidKeySpecException e) {
	        e.printStackTrace();
	    }
	    return privateKey;
	}
	
	//Decrypting SIDBI Request with SIDBI Public Key
	public static String decryptPK(byte[] dataPK, PublicKey publicKey) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
	    Cipher cipherPK = Cipher.getInstance("RSA/ECB/PKCS1Padding");
	    cipherPK.init(Cipher.DECRYPT_MODE, publicKey);
	    return new String(cipherPK.doFinal(dataPK));
	}
			
	public static String decryptPK(String dataPK, String base64PublicKey) throws IllegalBlockSizeException, InvalidKeyException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException {
	    return decryptPK(dataPK.getBytes(), getPublicKey(base64PublicKey));
	}
	
	//Decrypting SIDBI Request with IDBI Private Key
	public static String decrypt(byte[] data, PrivateKey privateKey) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
	    Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
	    cipher.init(Cipher.DECRYPT_MODE, privateKey);
	    return new String(cipher.doFinal(data));
	}
	
	public static String decrypt(String data, String base64PrivateKey) throws IllegalBlockSizeException, InvalidKeyException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException {
	   return decrypt(Base64.getDecoder().decode(data.getBytes()), getPrivateKey(base64PrivateKey));
	}
	// --- <<IS-END-SHARED>> ---
}

